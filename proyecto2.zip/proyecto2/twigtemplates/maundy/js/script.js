
(function () {

    var orden = 'c.categoria';
    var pagina = 1;
    var filtro = null;
    
    
     /* *******************************************
     * *******************************************
     * Botones
     * ******************************************
     * ******************************************/
    $('#addcategoria').on('click', function(event) {
         event.preventDefault();
       
        var categoria = $('#nuevacategoria').val().trim()
        if(categoria !== '' ) {
            genericAjax('ajax/addcategory', {'categoria': categoria}, 'get', function(json) {
                console.log(json);
                var option = "<option value='"+json.id_categoria+"'>"+json.nombre+"</option>"
                $('#listaSelect').append(option);
                
            });
        }
    });
    $('.btnPagina').on('click', function(e) {
         
            e.preventDefault();
            pagina = e.target.getAttribute('data-pagina');
            listar(); 
        });
    $('.borrar').on('click', function(e) {
            e.preventDefault();
            let id = e.target.getAttribute('data-id');
            borrar(id); 
    });
    $('#filtroBt').on('click', function(e) {
            e.preventDefault();
            filtro = document.getElementById('filtro').value;
            pagina = 1;
            listar(); 
        });
    
     
    $('#addenlace').on('click', function(event) {
        event.preventDefault();
        var mensaje;
        var select = document.getElementById("listaSelect")
        var selectedOption = select.options[select.selectedIndex];;
        var parametros = {
                href            : $('#url').val().trim(),
                comentario      : $('#comentario').val().trim(),
                categoria : selectedOption.value
            };
   
        if(parametros.categoria !== '' && parametros.href !== '' && parametros.comentario !== '') {
            genericAjax('ajax/addlink',parametros, 'get', function(json) {
                if(json.resultado == 0){
                    mensaje = 3;
                    muestraMensaje(mensaje);
                }else if(json.resultado == 1){
                    mensaje = 4;
                    muestraMensaje(mensaje);
                }
            });
        }
        
    });
    /******************************************
     * ****************************************
     * Fin de botones
     * ****************************************
     * ****************************************/


    var genericAjax = function (url, data, type, callBack) {
        $.ajax({
            url: url,
            data: data,
            type: type,
            dataType : 'json',
        })
        .done(function( json ) {
            console.log('ajax done');
            console.log(json);
            callBack(json);
        })
        .fail(function( xhr, status, errorThrown ) {
            console.log('ajax fail');
        })
        .always(function( xhr, status ) {
            console.log('ajax always');
        });
    }
    var muestraMensaje = function(mensaje){
        if (mensaje == 1){
            document.getElementById("alertmsg").style.display="block";
            document.getElementById("alertmsg").innerHTML="Borrado correctamente";
            document.getElementById("alertmsg").setAttribute("class","alert alert-success");
                setTimeout(function(){
                    document.getElementById("alertmsg").style.display="none";
                },2000);
        }else if(mensaje == 2){
                document.getElementById("alertmsg").style.display="block";
                document.getElementById("alertmsg").innerHTML="Error al Borrar";
                document.getElementById("alertmsg").setAttribute("class","alert alert-danger");
                setTimeout(function(){
                        document.getElementById("alertmsg").style.display="none";
                },2000);
            }else if(mensaje == 3){
                    document.getElementById("alertmsg").style.display="block";
                    document.getElementById("alertmsg").innerHTML="Insertado Correctamente";
                    document.getElementById("alertmsg").setAttribute("class","alert alert-success");
                    setTimeout(function(){
                        document.getElementById("alertmsg").style.display="none";
                    },2000);
            }else if (mensaje == 4){
                    document.getElementById("alertmsg").style.display="block";
                    document.getElementById("alertmsg").innerHTML="Error al insertar";
                    document.getElementById("alertmsg").setAttribute("class","alert alert-danger");
                    setTimeout(function(){
                        document.getElementById("alertmsg").style.display="none";
                    },2000);
            }
    }
    var borrar = function (id) {      
        var mensaje;
                genericAjax('ajax/borrar', {'id': id }, 'get', function(json) {
                    if(json.result===1){
                        mensaje = json.result;
                        muestraMensaje(mensaje);
                        listar();
                    }else{
                        json.result = 2;
                        mensaje = json.result;
                        mensaje = 2;
                        muestraMensaje(mensaje);
                    }
                    
                    
                });
               
    }
    var listar = function () {   
            
        genericAjax('ajax/listarLinks', {'pagina': pagina ,'orden' : orden, 'filtro' : filtro}, 'get', function(json) {
                    
                    console.log(json);
                    listarPaginas(json.paginas);
                    pintar(json.link);
                    
                });
               
    }

    var pintar = function (json) {
          
        $('#tbody').text('');
        	json.forEach(function(item){
    		$('#tbody').append(`
	    		<tr>
                  <td scope="row">${item.links.nombrecategoria}</td>
                  <td>${item.links.href}</td>
                  <td>${item.links.comentario}</td>
                  <td><button class="borrar btn btn-danger"  data-id=${item.links.id}>Eliminar</button></td>
                </tr>
                

                `);
    	});
    $('.borrar').on('click', function(e) {
            e.preventDefault();
            let id = e.target.getAttribute('data-id');
            borrar(id); 
    });
    $('.btnPagina').on('click', function(e) {
            e.preventDefault();
            pagina = e.target.getAttribute('data-pagina');
            listar(); 
        });
        
        
 
    }
    var listarPaginas = function (paginas) {
        var stringFirst = '<div class="col-md-3"><a href = "#" class = "btnPagina btn contact-submit" data-pagina='+paginas.primero+'>primero</a></div>';
        var stringPrev  = '<div class="col-md-3"><a href = "#" class = "btnPagina btn contact-submit" data-pagina='+paginas.anterior+'>anterior</a></div>';
        var stringRange = '';
    
        var stringNext = '<div class="col-md-3"><a href = "#" class = "btnPagina btn contact-submit" data-pagina='+paginas.siguiente+'>siguiente</a></div>';
        var stringLast = '<div class="col-md-3"><a href = "#" class = "btnPagina btn contact-submit" data-pagina='+paginas.ultimo+'>ultimo</a></div>';
        var finalString = stringFirst + stringPrev + stringRange + stringNext + stringLast;
        $('#pintarPaginas').empty();
        $('#pintarPaginas').append(finalString);
        $('.btnPagina2').on('click', function(e) {
            e.preventDefault();
            pagina = e.target.getAttribute('data-pagina');
            listar(); 
        });
  
   
    
    }

    
    
})();

