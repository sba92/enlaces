<?php

echo 'fin!';