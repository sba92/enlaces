<?php

namespace izv\app;


class App {
    
    const DATABASE = 'usuarios',
            HOST = 'localhost',
            USER = 'sba92',
            PASSWORD = '',
            
            
            EMAIL_TOKEN_FILE = 'https://finalmvc-sba92.c9users.io/token.conf',
            EMAIL_ALIAS = "Proyecto MVC",
            EMAIL_CLIENT_ID = '954652568311-qouj8o5cjhtfqvssginctnqrldv0bava.apps.googleusercontent.com',
            EMAIL_CLIENT_SECRET='vxKUErtrCHXUEud6CslftKMW',
            EMAIL_ORIGIN = 'pepeizv92@gmail.com',
            EMAIL_APPLICATION_NAME = 'usuario',

           
            JWT_KEY = 'Proyecto_App_Usuarios',
            
            
            SESSION_NAME = 'APP_MVC_SESSION',
            
            BASE= 'https://finalmvc-sba92.c9users.io/proyecto2/';

}

