<?php

namespace izv\controller;

use izv\app\App;
use izv\data\Usuario;
use izv\model\Model;
use izv\tools\Reader;
use izv\tools\Session;
use izv\tools\Util;
use izv\tools\Mail;
use izv\database\Database;
use izv\managedata\ManageUsuario;
use izv\managedata\Pagination;

class UserController extends Controller {
    
    
    function __construct(Model $model) {
        parent::__construct($model);
    }
    
    function dologin() {
         //1º control de sesión
        if($this->getSession()->isLogged()) {
            //5º producir resultado -> redirección
            header('Location: ' . App::BASE . 'index?op=login&r=session');
            exit();
        }

        //2º lectura de datos
        $usuario = Reader::readObject('izv\data\Usuario');

        //4º usar el modelo
        $r = $this->getModel()->login($usuario->getCorreo());
        
        if($r !== null){
            $resultado = Util::verificarClave($usuario->getClave(), $r->getClave());
        
            if($r !== false && $r->getActivo()==1 && $resultado){ 
                $r->setclave('');
                $this->getSession()->login($r);
                $r = 1;
            } else {
                $r = 0;
            }
        }
        //5º producir resultado -> redirección
        header('Location: ' . App::BASE . 'index?op=login&r=' . $r);
        exit();
    }

    function dologout() {
        $this->getSession()->logout();
        header('Location: ' . App::BASE . 'index');
        exit();
    }
    
    function addurl(){
        $r=0;
        if($this->getSession()->isLogged()){
            $this->getModel()->set('twigFile', '_addurl.html');
            $categorias =  $this->getModel()->getCategoriasUser($this->getSession()->getLogin()->getId() );
            $this->getModel()->set('categorias', $categorias);
        }else{
            header('Location: ' . App::BASE . 'index/main?op=edituser&r=' . $r);
            exit();
        }
    }
    function borrar() {
        $linkId = Reader::read('id');
        $result = $this->getModel()->borrarLink($linkId);
        $this->getModel()->set('result', ($result->getId() === null) ? 1 : 0);
    }
    function listarLinks(){
        $r=0;
        if($this->getSession()->isLogged()){
            $this->getModel()->set('twigFile', '_mainlogged.html');
            $pagina = Reader::read('pagina');
            if($pagina === null || !is_numeric($pagina)) {
                $pagina = 1;
            }
            $orden = Reader::read('orden');
            if(!isset($ordenes[$orden])) {
                $orden = 'c.categoria';
            }                       
            $links = $this->getModel()->doctrineLinks($this->getSession()->getLogin()->getId(), $pagina, $orden);

            $this->getModel()->set('lista', $links);
        }else{
            header('Location: ' . App::BASE . 'index/main?op=edituser&r=' . $r);
            exit();
        } 
    }
    
    function doregister() {
        //1º control de sesión
        if($this->getSession()->isLogged()) {
            //5º producir resultado -> redirección
            header('Location: ' . App::BASE . 'index?op=register&r=session');
            exit();
        }

        //2º lectura de datos
        $usuario = Reader::readObject('izv\data\Usuario');
        $clave2 = Reader::read('clave2');
        echo '<pre>' . var_export($usuario, true) . '</pre>';
        

        //4º usar el modelo
        $usuario->setClave(Util::encriptar($usuario->getClave()));
        echo '<pre>' . var_export($usuario, true) . '</pre>';
        $r = $this->getModel()->register($usuario);

        if($r > 0) {
            $resultado2 = Mail::sendActivation($usuario);
        }

        //5º producir resultado -> redirección
        header('Location: ' . App::BASE . 'index?op=register&r=' . $r);
        exit();
    }

    function login() {
        //1º control de sesión, si está logueado no se muestra el login
        if(!$this->getSession()->isLogged()) {
            //2º lectura de datos    -> no hay
            //3º validación de datos -> no hay
            //4º usar el modelo    -> no hace falta
            //5º producir resultado
            $this->getModel()->set('twigFile', '_login.html');
        }
    }
    
    function register() {
        //1º control de sesión, si está logueado no se muestra el registro
        if(!$this->getSession()->isLogged()) {
            //5º producir resultado
            $this->getModel()->set('twigFile', '_register.html');
        }
    }
    
    function doactivate(){
        $id = Reader::read('id');
        $code = Reader::read('code');
        
        $sendedMail = \Firebase\JWT\JWT::decode($code, App::JWT_KEY, array('HS256'));
        
        $r = $this->getModel()->activacion($id,$sendedMail);
        
        header('Location: ' . App::BASE . 'index/main?op=doactivate&r=' . $r);
        exit();

    }

    function main() {
        //1º control de sesión3
        if($this->getSession()->isLogged()) {
            
            $this->getModel()->set('twigFile', '_mainlogged.html');
            $this->getModel()->set('user', $this->getSession()->getLogin()->getCorreo());
            $user = $this->getSession()->getLogin();
            
            $pagina = Reader::read('pagina');
            if($pagina === null || !is_numeric($pagina)) {
                $pagina = 1;
            }
            
            $ordenes = array(
                'categoria' => 'c.categoria',
                'href' => 'l.href',
                'comentario' => 'l.comentario'
                );
            
            $orden = Reader::read('orden');
            
            if(!isset($ordenes[$orden])) {
                $orden = 'c.categoria';
            }
            else{
                $orden = $ordenes[$orden];
            }
            
            $links = $this->getModel()->getLinksDBPaginados($this->getSession()->getLogin()->getId(), $pagina, $orden);

            $this->getModel()->set('lista', $links);

        } else {
            //5º producir resultado
            $this->getModel()->set('twigFile', '_main.html');
        }
    }

    
}